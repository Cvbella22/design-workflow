// mockup generator placeholder
