// batch processor placeholder
