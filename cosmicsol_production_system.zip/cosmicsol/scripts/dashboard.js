// CLI dashboard placeholder
