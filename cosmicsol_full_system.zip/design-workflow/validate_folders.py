import os
ROOT=os.path.dirname(os.path.abspath(__file__))
req=['00_COLLECTIONS','01_DESIGNS','02_PSD_TEMPLATES','03_COMPLETED_MOCKUPS','04_MOCKUPS_OUTPUT','config','logs','metadata','modules','scripts']
for r in req:
 p=os.path.join(ROOT,r)
 if not os.path.exists(p): os.makedirs(p,exist_ok=True)
print("Folders validated.")
