#!/usr/bin/env node
const path=require('path');const fs=require('fs');const inq=require('inquirer');const chalk=require('chalk');
const ROOT=path.resolve(__dirname,'..');const MOD=path.join(ROOT,'modules');
function load(m){let p=path.join(MOD,m);if(fs.existsSync(p)){require(p).run();}else{console.log("Missing module:",m);}main();}
async function main(){console.clear();let c=await inq.prompt([{type:'list',name:'x',message:'Menu',choices:[
'Mockup Generator','Batch Processor','Template Builder','Export Manager','Image Tools','Metadata Tools','Backup Manager','Exit']}]);
switch(c.x){
case 'Mockup Generator':return load('mockup_generator.js');
case 'Batch Processor':return load('batch_processor.js');
case 'Template Builder':return load('template_builder.js');
case 'Export Manager':return load('export_manager.js');
case 'Image Tools':return load('image_tools.js');
case 'Metadata Tools':return load('metadata_tools.js');
case 'Backup Manager':return load('backup_manager.js');
default:process.exit(0);
}}
main();
