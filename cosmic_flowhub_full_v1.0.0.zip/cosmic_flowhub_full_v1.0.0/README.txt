# 🌙cOsMic sOl fLoW hUb⭐ — v1.0.0 Full Build Shell

This is a **working starting app** for your CosmicSol-style workflow:

- A Node/Express server (`app/server.js`)
- Simple API endpoints for status, settings, and designs
- A basic dashboard UI (`web/index.html`) with
  - Sidebar nav
  - Dashboard panel
  - Designs panel (reads files from `data/designs/`)
  - Settings panel (reads/writes `config/settings.json`)

Created: 2025-12-10T00:04:16.005285Z

## How to run

1. Open a terminal and go to the `app` folder in this project:
   - `cd app`
2. Install dependencies:
   - `npm install`
3. Start the server:
   - `npm start`
4. Open your browser to:
   - http://localhost:3000

## Where to plug your real workflow

- Put your Photoshop JSX scripts into `app/jsx/`.
- Put your Python helpers (FFmpeg, etc.) into `app/python/`.
- Replace the stub API routes in `app/server.js` (`/api/mockups/preview`, `/api/mockups/final`, `/api/export/etsy`) with real logic that calls your scripts.
- Use the `data/` folders for designs, previews, mockups, exports, and metadata.

This is not a finished commercial binary, but it *is* a functional hub you can immediately start and then evolve into your full CosmicSol Flow system.
