document.addEventListener('DOMContentLoaded', () => {
  // nav switching
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      const panel = btn.dataset.panel;
      document.getElementById('panel-' + panel).classList.add('active');
    });
  });

  // load status
  fetch('/api/status').then(r => r.json()).then(data => {
    document.getElementById('statusBox').textContent = JSON.stringify(data, null, 2);
  });

  // load settings
  fetch('/api/settings').then(r => r.json()).then(s => {
    document.getElementById('inpPreviewSize').value = s.defaultPreviewSize || 1000;
    document.getElementById('inpTheme').value = s.theme || 'dark_rainbow';
  });

  document.getElementById('saveSettings').addEventListener('click', () => {
    const body = {
      defaultPreviewSize: Number(document.getElementById('inpPreviewSize').value),
      theme: document.getElementById('inpTheme').value
    };
    fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then(r => r.json()).then(() => {
      alert('Settings saved.');
    });
  });

  // list designs
  document.getElementById('refreshDesigns').addEventListener('click', () => {
    fetch('/api/designs').then(r => r.json()).then(data => {
      const ul = document.getElementById('designList');
      ul.innerHTML = '';
      data.designs.forEach(d => {
        const li = document.createElement('li');
        li.textContent = d;
        ul.appendChild(li);
      });
    });
  });
});