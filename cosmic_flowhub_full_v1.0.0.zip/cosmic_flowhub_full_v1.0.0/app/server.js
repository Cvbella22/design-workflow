// 🌙cOsMic sOl fLoW hUb⭐ - Full Build Shell
// This is a functional Express server that serves the dashboard UI
// and exposes stub API endpoints you can later connect to your Photoshop/automation scripts.

const express = require("express");
const path = require("path");
const fs = require("fs");
const cors = require("cors");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");

const app = express();
const PORT = process.env.PORT || 3000;

const ROOT = path.resolve(__dirname, "..");
const CONFIG_DIR = path.join(ROOT, "config");
const DATA_DIR = path.join(ROOT, "data");

app.use(cors());
app.use(bodyParser.json());
app.use(cookieParser());

// --- load config helpers ---
function loadJSON(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(path.join(CONFIG_DIR, file), "utf8"));
  } catch (e) {
    return fallback;
  }
}

let settings = loadJSON("settings.json", {
  defaultPreviewSize: 1000,
  defaultFinalResolution: "1080p",
  defaultScenePreset: "none",
  theme: "dark_rainbow"
});

let system = loadJSON("system.json", {
  name: "cOsMic sOl fLoW hUb",
  version: "1.0.0",
  channel: "stable",
  build: 1
});

// --- Static UI ---
app.use("/", express.static(path.join(ROOT, "web")));

// --- Simple APIs ---

// status
app.get("/api/status", (req, res) => {
  res.json({
    ok: true,
    app: system.name,
    version: system.version,
    time: new Date().toISOString()
  });
});

// settings get
app.get("/api/settings", (req, res) => {
  res.json(settings);
});

// settings update
app.post("/api/settings", (req, res) => {
  settings = Object.assign(settings, req.body || {});
  fs.writeFileSync(path.join(CONFIG_DIR, "settings.json"), JSON.stringify(settings, null, 2));
  res.json({ ok: true });
});

// list designs (files in data/designs)
app.get("/api/designs", (req, res) => {
  const designsDir = path.join(DATA_DIR, "designs");
  if (!fs.existsSync(designsDir)) fs.mkdirSync(designsDir, { recursive: true });
  const files = fs.readdirSync(designsDir).filter(f => !f.startsWith("."));
  res.json({ designs: files });
});

// placeholder endpoints for future integration
app.post("/api/mockups/preview", (req, res) => {
  // You will connect this to your Photoshop JSX batch preview script.
  res.json({ ok: true, message: "Preview pipeline stub called (hook to Photoshop here)." });
});

app.post("/api/mockups/final", (req, res) => {
  // You will connect this to your Photoshop JSX final render script.
  res.json({ ok: true, message: "Final pipeline stub called (hook to Photoshop here)." });
});

app.post("/api/export/etsy", (req, res) => {
  // You will connect this to your Etsy CSV / API uploader later.
  res.json({ ok: true, message: "Etsy export stub called (connect uploader module here)." });
});

app.listen(PORT, () => {
  console.log("🌙cOsMic sOl fLoW hUb⭐ server running on http://localhost:" + PORT);
});
